# vsmodtemplate

This repository contains a configured VisualStudio project that let's you start Vintage Story and add your own mod projects to it. Supports logging and as well as debugging. All projects in `root/mods/` will be loaded.
